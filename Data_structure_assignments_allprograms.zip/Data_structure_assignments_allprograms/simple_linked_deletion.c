//only deletion of simple linked list
#include <stdio.h>
#include <stdlib.h>
 
struct Node
{
    int value;
    struct Node *next;
};
//display
void linkedlist(struct Node*p)
{
   while(p!=NULL)
   {
       printf("elements: %d\n",p->value);
       p=p->next;
   }
} 
//delete from front
struct Node*delete_front(struct Node *head)
{
   struct Node *p=head;
   head=head->next;
   free(p);
   return head;
}   
  
//delete from end
struct Node*delete_end(struct Node *head)
{ 
   struct Node *p=head;
   struct Node *q=head->next;
   while(q->next!=NULL)
   {
      p=p->next;
      q=q->next;
      }
      p->next= q->next;
      free(q);
      return head;
   
}    
     
//in bet
struct Node *delete_between(struct Node* head,int index)
{
  struct Node*p=head;
  struct Node*q=head->next;
  for(int i=0;i<index-1;i++)
  {
     p=p->next;
     q=q->next;
   }
   p->next=q->next;
   free(q);
   return head;
   
 }
 
 
int final()
{
    int op;
    printf("\n");
    printf("\noperations of linked list\n");
    printf("enter 1 for deletion in front\n");
    printf("enter 2 for deletion in end\n");
    printf("enter 3 for deletion in between\n");
    printf("enter 4 to display the linked list\n");
    
    scanf("%d",&op);
    return op;
    
}

int main()
{
  struct Node * head;
   struct Node *second;
   struct Node *third;
   struct Node *fourth;
   
   head=(struct Node *) malloc(sizeof (struct Node));
   second=(struct Node*)malloc(sizeof (struct Node));
   third=(struct Node*)malloc(sizeof (struct Node));
   fourth=(struct Node*)malloc(sizeof (struct Node)); 
   
   head->value=7;
   head->next=second;
   
   second->value=9;
   second->next=third;
   
   
   third->value =66;
   third->next=fourth;
   
   fourth->value=77;
   fourth->next=NULL;
    
     while(1)
    {
    switch(final())
    {  
      case 1:
      head=delete_front(head);
      linkedlist(head);
      break;
      
      
      case 2:
     // linkedlist(head);
      head=delete_end(head);
      linkedlist(head);
      break;
      
      case 3:
     //linkedlist(head);
      head=delete_between(head,1);
      linkedlist(head);
      break;
      
      case 4:
      linkedlist(head);
      break;
      
      default:
      printf("Invalid input \n");
      
      }
      
      }
 
    //linkedListTraversal(head);
    return 0;
}

 
  
